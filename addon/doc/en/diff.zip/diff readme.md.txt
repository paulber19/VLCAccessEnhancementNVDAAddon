
readme.md
diff between version 2.9.1 (<) and version 2.10 (>)12c12

< 	* Last NVDA version tested: 2022.3
---
> 	* Last NVDA version tested: 2023.1
38,39c38,39
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.9.1.nvda-addon
< [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.9.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.10.nvda-addon
> [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.10.nvda-addon
