readme.md
diff between version 2.12.2 (<) and version 2.13 (>)12c12
11,12c11,12
< 	* Minimum required NVDA version: 2023.1
< 	* Last NVDA version tested: 2024.4
---
> 	* Minimum required NVDA version: 2024.1
> 	* Last NVDA version tested: 2025.1
37,38c37,38
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.12.1.nvda-addon
< [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.12.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.13.nvda-addon
> [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.13.nvda-addon
