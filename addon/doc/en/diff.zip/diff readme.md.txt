readme.md
diff between version 2.11 (<) and version 2.12 (>)12c12
11,13c11,12
< 	* Minimum required NVDA version: 2022.1
< 	* Last NVDA version tested: 2024.1
< 
---
> 	* Minimum required NVDA version: 2023.1
> 	* Last NVDA version tested: 2024.4
38,39c37,38
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.11.nvda-addon
< [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.11.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.12.nvda-addon
> [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.12.nvda-addon
