readme.md
diff between version 2.10 (<) and version 2.11 (>)12c12
11,12c11,12
< 	* Minimum required NVDA version: 2020.4
< 	* Last NVDA version tested: 2023.1
---
> 	* Minimum required NVDA version: 2022.1
> 	* Last NVDA version tested: 2024.1
38,39c38,39
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.10.nvda-addon
< [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.10.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.11.nvda-addon
> [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.11.nvda-addon
