readme.md
diff between version 2.13 (<) and version 2.14 (>)12c12
1,48c1,39
< <!DOCTYPE html>
< <html lang="en" dir="ltr">
< <head>
< <meta charset="utf-8">
< <title>VLC multimedia player: Accessibility enhancements 2.13</title>
< <meta name="viewport" content="width=device-width, initial-scale=1" />
< <link rel="stylesheet" href=..\styles.css>
< <link rel="stylesheet" href=..\numberedHeadings.css
< </head><body>
< <h1 id="vlc-multimedia-player-accessibility-enhancement">VLC multimedia player: accessibility enhancement</h1>
< <ul>
< <li>Author : PaulBer19</li>
< <li>URL : paulber19@laposte.net</li>
< <li>GitHub repository: <a href="https://github.com/paulber19/VLCAccessEnhancementNVDAAddon.git">https://github.com/paulber19/VLCAccessEnhancementNVDAAddon.git</a></li>
< <li>Download:<ul>
< <li><a href="https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.13.nvda-addon">stable version server 1</a></li>
< <li><a href="http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.13.nvda-addon">stable version server 2</a></li>
< <li>Download <a href="https://github.com/paulber007/AllMyNVDAAddons/tree/master/vlcAccessEnhancement/dev">developpement version</a></li>
< </ul>
< </li>
< <li>Compatibility:<ul>
< <li>Minimum required NVDA version: 2024.1</li>
< <li>Last NVDA version tested: 2025.1</li>
< </ul>
< </li>
< </ul>
< <p>This addon adds a variety of commands to enhance accessibility in playing media:</p>
< <ul>
< <li>script to announce the duration of the media you&rsquo;ve already played,</li>
< <li>script to announce the duration of the media remaining to be play,</li>
< <li>script to announce the total duration of the media,</li>
< <li>script to announce the current speed,</li>
< <li>automatic announcement of state&rsquo;s changes such as pause , mute, changing the pitch or speed of playback, and the setting repeated playback or random,</li>
< <li>automatic announcement of the time after a command to jump,</li>
< <li>scripts to mark playback position and start playback at this position,</li>
< <li>script to restart interrupted playback at time recorded by VLC,</li>
< <li>correct reading of the status bar,</li>
< <li>change of some VLC&rsquo;s annoying keyboard shortcuts of VLC.</li>
< <li>and others enhancements as:</li>
< <li>access to playback controls (feature &lsquo;s idea of Javi Dominguez),</li>
< <li>access to adjustments and effects dialog,</li>
< <li>correct announcement of name and value &lsquo;s slider,</li>
< <li>deleting of some useless html text in description&rsquo;s object(code from Javi Dominguez add-on).</li>
< </ul>
< <p>The list of commands is obtained by Control+NVDA+H</p>
< <p>Compatible with VLC 3.0.</p>
< </body>
< </html>
---
> # VLC multimedia player: accessibility enhancement #
> 
> * Author : PaulBer19
> * URL : paulber19@laposte.net
> * GitHub repository: <https://github.com/paulber19/VLCAccessEnhancementNVDAAddon.git>
> * Download:
> 	* [stable version server 1][1]
> 	* [stable version server 2][2]
> 	* Download [developpement version][3]
> * Compatibility:
> 	* Minimum required NVDA version: 2025.1
> 	* Last NVDA version tested: 2026.1
> 
> This addon adds a variety of commands to enhance accessibility in playing media:
> 
> * script to announce the duration of the media you've already played,
> * script to announce the duration of the media remaining to be play,
> * script to announce the total duration of the media,
> * script to announce the current speed,
> * automatic announcement of state's changes such as pause , mute, changing the pitch or speed of playback, and the setting repeated playback or random,
> * automatic announcement of the time after a command to jump,
> * scripts to mark playback position and start playback at this position,
> * script to restart interrupted playback at time recorded by VLC,
> * correct reading of the status bar,
> * change of some VLC's annoying keyboard shortcuts of VLC.
> * and others enhancements as:
>  * access to playback controls (feature 's idea of Javi Dominguez),
>  * access to adjustments and effects dialog,
>  * correct announcement of name and value 's slider,
>  * deleting of some useless html text in description's object(code from Javi Dominguez add-on).
> 
> 
> The list of commands is obtained by Control+NVDA+H
> 
> Compatible with VLC 3.0.
> 
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/VLC/VLCAccessEnhancement-2.14.nvda-addon
> [2]: http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/data/VLCAccessEnhancement-2.14.nvda-addon
> [3]:https://github.com/paulber007/AllMyNVDAAddons/tree/master/vlcAccessEnhancement/dev
